export const kbd = {
  BACKSPACE: 'Backspace',
  SLASH: '/',
  K: 'k',
  S: 's',
  E: 'e'
};
